#include "state.h"

state::state(){ }

state::state(int identifier, bool acceptance) : 
identifier(identifier), 
acceptance(acceptance){ }