class state{
    public:
        int identifier;
        bool acceptance;

        state();
        state(int identifier, bool acceptance);        
};